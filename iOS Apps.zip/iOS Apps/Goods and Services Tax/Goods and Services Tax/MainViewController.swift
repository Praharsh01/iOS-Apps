//
//  ViewController.swift
//  Goods and Services Tax
//
//  Created by Praharsh Gaudani on 01/03/2021.
//

import UIKit
import SafariServices

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK: - Buttons for Social Media
    
    @IBAction func instagram1(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "http://www.instagram.com/prahlu_1334/")!)
        present(vc, animated: true)
    }
    
    
    @IBAction func facebook1(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.facebook.com/praharsh.gaudani/")!)
        present(vc, animated: true)
    }
    
    @IBAction func twitter(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://twitter.com/PraharshGaudan1")!)
        present(vc, animated: true)
        
    }
    
}
