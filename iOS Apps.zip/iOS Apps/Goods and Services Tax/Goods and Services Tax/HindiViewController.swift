//
//  EnglishViewController.swift
//  Goods and Services Tax
//
//  Created by Praharsh Gaudani on 22/03/2021.
//

import UIKit
import SafariServices

class HindiViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
//MARK: - Button for Home
@IBAction func home(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in")!)
    present(vc, animated: true)
}

//MARK: - Button for GST Law
@IBAction func GSTLaw(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/gstlaw/gstlawlist")!)
    present(vc, animated: true)
}

//MARK: - Button for Help and Taxpayers Facilities
@IBAction func helpAndTaxpayersFacilities(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/HelpandTaxpayer/HelpandTaxpayerfacilities")!)
    present(vc, animated: true)
}

//MARK: - Button for e-Invoice
@IBAction func einvoice(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/invoice/einvoice")!)
    present(vc, animated: true)
}

//MARK: - Buttons for Services
@IBAction func ewaybill(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/ewaybill/ewaybillsystem")!)
    present(vc, animated: true)
}

@IBAction func ApplicationStatus(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/trackstatus")!)
    present(vc, animated: true)
}

//MARK: - Buttons for Registration

@IBAction func NewRegistration(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://reg.gst.gov.in/registration")!)
    present(vc, animated: true)
}

@IBAction func ApplicationForFilling(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://reg.gst.gov.in/registration/")!)
    present(vc, animated: true)
}

@IBAction func TrackApplication(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/arnstatus")!)
    present(vc, animated: true)
}

//MARK: - Buttons for Payments

@IBAction func CreateChallan(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://payment.gst.gov.in/payment/")!)
    present(vc, animated: true)
}

@IBAction func Grievance(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/grievance")!)
    present(vc, animated: true)
}

@IBAction func TrackPaymentStatus(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://payment.gst.gov.in/payment/trackpayment")!)
    present(vc, animated: true)
}

//MARK: - Buttons for User Services

@IBAction func HolidayList(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/holiday")!)
    present(vc, animated: true)
}

@IBAction func GenerateUserId(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://reg.gst.gov.in/registration/generateuid")!)
    present(vc, animated: true)
}

@IBAction func LocateGST(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/locategstp")!)
    present(vc, animated: true)
}

@IBAction func CauseList(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/litserv/case/hrng/get")!)
    present(vc, animated: true)
}

//MARK: - Button for Refunds

@IBAction func TrackApplicationStatus(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://refund.gst.gov.in/refunds/pre/trackarnstatus")!)
    present(vc, animated: true)
}

//MARK: - Button for Downloads

@IBAction func GSTStatistics(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gststatistics")!)
    present(vc, animated: true)
}

//MARK: - Buttons for Search Taxpayers

@IBAction func GSTIN(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/searchtp")!)
    present(vc, animated: true)
}

@IBAction func PAN(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/searchtpbypan")!)
    present(vc, animated: true)
}

@IBAction func Taxpayer(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://services.gst.gov.in/services/listoftaxpayer")!)
    present(vc, animated: true)
}

//MARK: - Buttons for Offline Tools

@IBAction func ReturnOffline(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/returns")!)
    present(vc, animated: true)
}

@IBAction func Matching(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr2b")!)
    present(vc, animated: true)
}

@IBAction func Tran1(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/trans1b")!)
    present(vc, animated: true)
}

@IBAction func Tran2(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/trans2")!)
    present(vc, animated: true)
}

@IBAction func GSTR3B(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr3b")!)
    present(vc, animated: true)
}

@IBAction func ITC01(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/itc01")!)
    present(vc, animated: true)
}

@IBAction func ITC03(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/itc03")!)
    present(vc, animated: true)
}

@IBAction func ITC04(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/itc04")!)
    present(vc, animated: true)
}

@IBAction func GSTARA01(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://tutorial.gst.gov.in/downloads/advancerulingtaxpayer.zip")!)
    present(vc, animated: true)
}

@IBAction func GSTR4(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr4/offline")!)
    present(vc, animated: true)
}

@IBAction func GSTR6(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://tutorial.gst.gov.in/offlineutilities/returns/GSTR_6_Offline_Utility.zip")!)
    present(vc, animated: true)
}

@IBAction func GSTR11(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://tutorial.gst.gov.in/offlineutilities/returns/GSTR_11_Offline_Utility.zip")!)
    present(vc, animated: true)
}

@IBAction func GSTR7(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr7")!)
    present(vc, animated: true)
}

@IBAction func GSTR8(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr8")!)
    present(vc, animated: true)
}

@IBAction func GSTR10(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr10")!)
    present(vc, animated: true)
}

@IBAction func GSTR9(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr9")!)
    present(vc, animated: true)
}

@IBAction func GSTR9A(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr9a")!)
    present(vc, animated: true)
}

@IBAction func GSTR9C(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr9c")!)
    present(vc, animated: true)
}

@IBAction func GSTR4Annual(_ sender: UIButton) {
    let vc = SFSafariViewController(url: URL(string: "https://www.gst.gov.in/download/gstr4x")!)
    present(vc, animated: true)
}

}
