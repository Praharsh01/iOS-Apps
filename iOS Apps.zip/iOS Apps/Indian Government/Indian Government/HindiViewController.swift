
import UIKit
import SafariServices

class HindiViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    //MARK: - Button for Home
    @IBAction func home(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi")!)
        present(vc, animated: true)
    }
    
    //MARK: - Buttons for Topics
    @IBAction func agriculture(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/agriculture")!)
        present(vc, animated: true)
    }
    
    @IBAction func commerce(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/commerce")!)
        present(vc, animated: true)
    }
    
    
    @IBAction func defence(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/defence")!)
        present(vc, animated: true)
    }
    
    @IBAction func EnvironmentForest(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/environment-forest")!)
        present(vc, animated: true)
    }
    
    @IBAction func FoodPublicDistribution(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/food-public-distribution")!)
        present(vc, animated: true)
    }
    
    @IBAction func GovernanceAdministration(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/governance-administration")!)
        present(vc, animated: true)
    }
    
    @IBAction func Housing(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/housing")!)
        present(vc, animated: true)
    }
    
    @IBAction func Industries(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/industries")!)
        present(vc, animated: true)
    }
    
    @IBAction func InformationBroadcasting(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/information-broadcasting")!)
        present(vc, animated: true)
    }
    
    @IBAction func LawJustice(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/law-justice")!)
        present(vc, animated: true)
    }
    
    @IBAction func Rural(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/rural")!)
        present(vc, animated: true)
    }
    
    @IBAction func SocialDevelopment(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/social-development")!)
        present(vc, animated: true)
    }
    
    @IBAction func TravelTourism(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/travel-tourism")!)
        present(vc, animated: true)
    }
    
    @IBAction func ArtCulture(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/art-culture")!)
        present(vc, animated: true)
    }
    
    @IBAction func Communication(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/communication")!)
        present(vc, animated: true)
    }
    
    @IBAction func Education(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/education")!)
        present(vc, animated: true)
    }
    
    @IBAction func FinanceTaxes(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/finance-taxes")!)
        present(vc, animated: true)
    }
    
    @IBAction func ForeignAffairs(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/foreign-affairs")!)
        present(vc, animated: true)
    }
    
    @IBAction func HealthFamilyWelfare(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/health-family-welfare")!)
        present(vc, animated: true)
    }
    
    @IBAction func HomeAffairsEnforcement(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/home-affairs-enforcement")!)
        present(vc, animated: true)
    }
    
    @IBAction func Infrastructure(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/infrastructure")!)
        present(vc, animated: true)
    }
    
    @IBAction func LabourEmployment(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/labour-employment")!)
        present(vc, animated: true)
    }
    
    @IBAction func PowerEnergy(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/power-energy")!)
        present(vc, animated: true)
    }
    
    @IBAction func ScienceTechnology(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/science-technology")!)
        present(vc, animated: true)
    }
    
    @IBAction func Transport(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/transport")!)
        present(vc, animated: true)
    }
    
    @IBAction func YouthSports(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/youth-sports")!)
        present(vc, animated: true)
    }
    
    //MARK: - Button for service
  
    @IBAction func service(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://services.india.gov.in/?ln=hi")!)
        present(vc, animated: true)
    }
    
    //MARK: - Button for My Government

    @IBAction func ConstitutionofIndia(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/my-government/constitution-india")!)
        present(vc, animated: true)
    }
    
    @IBAction func IndianParliament(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/my-government/indian-parliament")!)
        present(vc, animated: true)
    }
    
    @IBAction func WhosWho(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/my-government/whos-who")!)
        present(vc, animated: true)
    }
    
    @IBAction func Schemes(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/my-government/schemes")!)
        present(vc, animated: true)
    }
    
    @IBAction func Forms(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/my-government/forms")!)
        present(vc, animated: true)
    }
    
    @IBAction func GovernmentDirectory(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/my-government/government-directory")!)
        present(vc, animated: true)
    }
    
    @IBAction func Publications(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/my-government/publications")!)
        present(vc, animated: true)
    }
    
    @IBAction func Acts(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.indiacode.nic.in")!)
        present(vc, animated: true)
    }
    
    @IBAction func Documents(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/my-government/documents")!)
        present(vc, animated: true)
    }
    
    //MARK: - Button for People groups
    
    @IBAction func Community(_ sender: UIButton) {
            let vc = SFSafariViewController(url: URL(string:  "https://www.india.gov.in/hi/people-groups/community")!)
            present(vc, animated: true)
    }
    
    @IBAction func LifeCycle(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string:  "https://www.india.gov.in/hi/people-groups/life-cycle")!)
        present(vc, animated: true)
    }
    
    //MARK: - Button for Know India
  
    @IBAction func Profile(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/profile")!)
        present(vc, animated: true)
    }
    
    @IBAction func MyIndiaMyPride(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://knowindia.gov.in/hindi/")!)
        present(vc, animated: true)
    }
    
    @IBAction func DistrictsofIndia(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/districts-india")!)
        present(vc, animated: true)
    }
    
    @IBAction func NaturalWonders(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/natural-wonders")!)
        present(vc, animated: true)
    }
    
    @IBAction func TravelAdvisory(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/travel-advisory")!)
        present(vc, animated: true)
    }
    
    @IBAction func History(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://knowindia.gov.in/hindi/culture-and-heritage/ancient-history.php")!)
        present(vc, animated: true)
    }
    
    @IBAction func NationalSymbols(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/national-symbols")!)
        present(vc, animated: true)
    }
    
    @IBAction func PeopleandLifestyle(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/people-and-lifestyle")!)
        present(vc, animated: true)
    }
    
    @IBAction func Wheretostay(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/where-stay")!)
        present(vc, animated: true)
    }
    
    @IBAction func TravelAgents(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/travel-agents")!)
        present(vc, animated: true)
    }
    
    @IBAction func StatesofIndia(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/states-india")!)
        present(vc, animated: true)
    }
    
    @IBAction func CultureHeritage(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/culture-heritage")!)
        present(vc, animated: true)
    }
    
    @IBAction func PlacestoVisit(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/india-glance/places-visit")!)
        present(vc, animated: true)
    }
    
    @IBAction func ModesofTravel(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.india.gov.in/hi/topics/travel-tourism/modes-travel")!)
        present(vc, animated: true)
    }
}
