import UIKit
import SafariServices

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //MARK: - Button for Social Media
    
    @IBAction func instagram(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "http://www.instagram.com/prahlu_1334/")!)
        present(vc, animated: true)
    }
    
    @IBAction func facebook(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.facebook.com/praharsh.gaudani/")!)
        present(vc, animated: true)
    }
    
    @IBAction func gmail(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://twitter.com/PraharshGaudan1")!)
        present(vc, animated: true)
    }
        
}
