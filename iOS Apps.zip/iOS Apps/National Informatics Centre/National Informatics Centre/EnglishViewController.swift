//
//  ViewController.swift
//  National Informatics Centre
//
//  Created by Praharsh Gaudani on 05/03/2021.
//

import UIKit
import SafariServices

class EnglishViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //MARK: - Button for Main Page
    @IBAction func home(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in")!)
        present(vc, animated: true)
    }
    
    @IBAction func Services(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/services-main-page/")!)
        present(vc, animated: true)
    }
    
    @IBAction func ProductsAndBacklogs(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/projects-all/")!)
        present(vc, animated: true)
    }
    
    @IBAction func EmergingTechnologies(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/emerging-technology/")!)
        present(vc, animated: true)
    }
    
    @IBAction func Alumni(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/alumniconnect/")!)
        present(vc, animated: true)
    }
    
    //MARK: - Buttons for NIC Offices
    @IBAction func Headquarters(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/about-us/")!)
        present(vc, animated: true)
    }
    
    @IBAction func DataCentres(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/data-centre/")!)
        present(vc, animated: true)
    }
    
    @IBAction func FocusCentres(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/special-centre-2/")!)
        present(vc, animated: true)
    }
    
    @IBAction func CentresOfExcellence(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/centre-of-excellence/")!)
        present(vc, animated: true)
    }
    
    @IBAction func StateCentres(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/state-office/")!)
        present(vc, animated: true)
    }
    
    @IBAction func DistrictCentres(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/district-offices/")!)
        present(vc, animated: true)
    }
    
    //MARK: - Buttons for Media
    @IBAction func Awards(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/nic-awards/")!)
        present(vc, animated: true)
    }
    
    @IBAction func Blogs(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/blogs/")!)
        present(vc, animated: true)
    }
    
    @IBAction func Infographics(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/infographics/")!)
        present(vc, animated: true)
    }
    
    @IBAction func VideoGallery(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/videos-gallery/")!)
        present(vc, animated: true)
    }
    
    @IBAction func testimonials(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/testimonials-all/")!)
        present(vc, animated: true)
    }
    
    @IBAction func Informatics(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://informatics.nic.in")!)
        present(vc, animated: true)
    }
    
    @IBAction func Newsletter(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/news-letter/")!)
        present(vc, animated: true)
    }
    
    //MARK: - Buttons for About Us
    @IBAction func OrganizationChart(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/org_structure/")!)
        present(vc, animated: true)
    }
    
    @IBAction func WhosWho(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/whos-who/")!)
        present(vc, animated: true)
    }
    
    @IBAction func Directory(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/directory/")!)
        present(vc, animated: true)
    }
    
    @IBAction func Timeline(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://digitaljourney.nic.in/nic-timeline")!)
        present(vc, animated: true)
    }
    
    @IBAction func RTI(_ sender: UIButton) {
        let vc = SFSafariViewController(url: URL(string: "https://www.nic.in/rti/")!)
        present(vc, animated: true)
    }
   
}

